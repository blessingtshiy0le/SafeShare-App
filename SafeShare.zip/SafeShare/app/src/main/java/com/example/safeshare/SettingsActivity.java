package com.example.safeshare;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class SettingsActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "safeshare_prefs";
    private static final String KEY_LANGUAGE = "pref_language";
    private static final String KEY_DARK = "pref_dark";
    private static final String KEY_NOTIF = "pref_notif";

    Spinner languageSpinner;
    Switch darkSwitch, notifSwitch;
    Button saveBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Apply theme immediately so UI shows chosen theme
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean dark = prefs.getBoolean(KEY_DARK, false);
        if (dark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }

        setContentView(R.layout.activity_settings);

        languageSpinner = findViewById(R.id.settingsLanguageSpinner);
        darkSwitch = findViewById(R.id.settingsDarkSwitch);
        notifSwitch = findViewById(R.id.settingsNotifSwitch);
        saveBtn = findViewById(R.id.settingsSaveBtn);

        String[] languages = {"English", "Zulu", "Xhosa"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, languages);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        languageSpinner.setAdapter(adapter);

        // Load saved prefs
        String savedLang = prefs.getString(KEY_LANGUAGE, "English");
        boolean savedDark = prefs.getBoolean(KEY_DARK, false);
        boolean savedNotif = prefs.getBoolean(KEY_NOTIF, true);

        // set UI to saved
        int idx = 0;
        for (int i = 0; i < languages.length; i++) {
            if (languages[i].equals(savedLang)) { idx = i; break; }
        }
        languageSpinner.setSelection(idx);
        darkSwitch.setChecked(savedDark);
        notifSwitch.setChecked(savedNotif);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String chosen = languageSpinner.getSelectedItem().toString();
                boolean darkVal = darkSwitch.isChecked();
                boolean notifVal = notifSwitch.isChecked();

                SharedPreferences.Editor editor = prefs.edit();
                editor.putString(KEY_LANGUAGE, chosen);
                editor.putBoolean(KEY_DARK, darkVal);
                editor.putBoolean(KEY_NOTIF, notifVal);
                editor.apply();

                // Apply theme immediately
                if (darkVal) AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                else AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

                Toast.makeText(SettingsActivity.this, "Settings saved", Toast.LENGTH_SHORT).show();
            }
        });
    }
}

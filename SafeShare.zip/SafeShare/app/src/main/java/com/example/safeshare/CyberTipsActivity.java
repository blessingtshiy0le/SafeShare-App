package com.example.safeshare;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;

public class CyberTipsActivity extends AppCompatActivity {
    ListView tipsList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cyber_tips);

        tipsList = findViewById(R.id.tipsList);

        String[] tips = {
                "Use strong passwords",
                "Don't click suspicious links",
                "Keep your software updated",
                "Report any scams you see"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, tips);
        tipsList.setAdapter(adapter);
    }
}

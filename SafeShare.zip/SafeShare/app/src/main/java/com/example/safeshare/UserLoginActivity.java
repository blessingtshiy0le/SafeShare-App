package com.example.safeshare;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class UserLoginActivity extends AppCompatActivity {

    private static final String PREFS_NAME = "safeshare_prefs";
    private static final String KEY_LOGGED_IN = "logged_in";
    private static final String KEY_USERNAME = "username";

    EditText etUsername, etPassword;
    Button btnLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // load theme preference first (optional)
        applyThemeFromPrefs();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_login);

        // If already logged in, skip login screen
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean loggedIn = prefs.getBoolean(KEY_LOGGED_IN, false);
        if (loggedIn) {
            // go straight to Dashboard
            startActivity(new Intent(this, DashboardActivity.class));
            finish();
            return;
        }

        etUsername = findViewById(R.id.etLoginUsername);
        etPassword = findViewById(R.id.etLoginPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String u = etUsername.getText().toString().trim();
                String p = etPassword.getText().toString().trim();

                if (TextUtils.isEmpty(u)) {
                    etUsername.setError("Enter username");
                    return;
                }
                if (TextUtils.isEmpty(p)) {
                    etPassword.setError("Enter password");
                    return;
                }

                // --- Simple local auth for assignment purposes ---
                // In production you'd validate against secure backend.
                // For now accept any non-empty username/password.
                SharedPreferences.Editor editor = prefs.edit();
                editor.putBoolean(KEY_LOGGED_IN, true);
                editor.putString(KEY_USERNAME, u);
                editor.apply();

                Toast.makeText(UserLoginActivity.this, "Login successful", Toast.LENGTH_SHORT).show();

                // Go to Dashboard
                startActivity(new Intent(UserLoginActivity.this, DashboardActivity.class));
                finish();
            }
        });
    }

    private void applyThemeFromPrefs() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        boolean dark = prefs.getBoolean("pref_dark", false);
        if (dark) {
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(
                    androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            androidx.appcompat.app.AppCompatDelegate.setDefaultNightMode(
                    androidx.appcompat.app.AppCompatDelegate.MODE_NIGHT_NO);
        }
    }
}

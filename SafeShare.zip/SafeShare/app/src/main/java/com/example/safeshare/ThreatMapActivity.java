package com.example.safeshare;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.location.Location;
import android.os.Bundle;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class ThreatMapActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_REQUEST_CODE = 200;
    ThreatDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_threat_map);

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        dbHelper = new ThreatDatabaseHelper(this);

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Request or enable location
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            enableMyLocationAndZoom();
        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_REQUEST_CODE);
        }

        // Load markers from SQLite DB
        loadMarkersFromSQLite();
    }

    private void enableMyLocationAndZoom() {
        try {
            if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                mMap.setMyLocationEnabled(true);
                fusedLocationClient.getLastLocation().addOnSuccessListener(this, (Location location) -> {
                    if (location != null) {
                        LatLng cur = new LatLng(location.getLatitude(), location.getLongitude());
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(cur, 12f));
                    }
                });
            }
        } catch (SecurityException e) {
            e.printStackTrace();
        }
    }

    private void loadMarkersFromSQLite() {
        Cursor c = dbHelper.getReadableDatabase().query("threats",
                new String[]{"id","category","description","date","latitude","longitude"},
                null, null, null, null, null);

        if (c == null) return;
        while (c.moveToNext()) {
            double lat = c.getDouble(c.getColumnIndexOrThrow("latitude"));
            double lon = c.getDouble(c.getColumnIndexOrThrow("longitude"));
            String category = c.getString(c.getColumnIndexOrThrow("category"));
            String desc = c.getString(c.getColumnIndexOrThrow("description"));
            String date = c.getString(c.getColumnIndexOrThrow("date"));

            // skip invalid coords
            if (lat == 0.0 && lon == 0.0) continue;

            LatLng pos = new LatLng(lat, lon);
            float hue = getMarkerHue(category);
            mMap.addMarker(new MarkerOptions()
                    .position(pos)
                    .title(category + " — " + shortText(desc, 40))
                    .snippet(date + "\n" + desc)
                    .icon(BitmapDescriptorFactory.defaultMarker(hue)));
        }
        c.close();

        mMap.setOnInfoWindowClickListener(marker -> {
            Toast.makeText(this, marker.getSnippet(), Toast.LENGTH_LONG).show();
            // optionally open detail/edit screen
        });
    }

    private String shortText(String s, int n) {
        if (s == null) return "";
        return s.length() > n ? s.substring(0, n) + "…" : s;
    }

    private float getMarkerHue(String category) {
        if (category == null) return BitmapDescriptorFactory.HUE_AZURE;
        switch (category.toLowerCase()) {
            case "phishing": return BitmapDescriptorFactory.HUE_RED;
            case "malware": return BitmapDescriptorFactory.HUE_YELLOW;
            case "scam": return BitmapDescriptorFactory.HUE_ORANGE;
            default: return BitmapDescriptorFactory.HUE_AZURE;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == LOCATION_REQUEST_CODE) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED) {
                enableMyLocationAndZoom();
            } else {
                Toast.makeText(this, "Location permission denied. Map will still show stored markers.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}

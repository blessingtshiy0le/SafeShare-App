package com.example.safeshare;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {
    Button reportBtn, tipsBtn, mapBtn, settingsBtn, logoutBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        reportBtn = findViewById(R.id.reportBtn);
        tipsBtn = findViewById(R.id.tipsBtn);
        mapBtn = findViewById(R.id.mapBtn);
        settingsBtn = findViewById(R.id.settingsBtn);
        logoutBtn = findViewById(R.id.logoutBtn);

        reportBtn.setOnClickListener(v -> startActivity(new Intent(this, ReportThreatActivity.class)));
        tipsBtn.setOnClickListener(v -> startActivity(new Intent(this, CyberTipsActivity.class)));
        mapBtn.setOnClickListener(v -> startActivity(new Intent(this, MapActivity.class)));
        settingsBtn.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));

        logoutBtn.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle("Logout")
                    .setMessage("Are you sure you want to logout?")
                    .setPositiveButton("Logout", (dialog, which) -> finish())
                    .setNegativeButton("Cancel", null)
                    .show();
        });
    }
}

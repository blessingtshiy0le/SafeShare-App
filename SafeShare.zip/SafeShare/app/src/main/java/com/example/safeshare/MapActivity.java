package com.example.safeshare;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MapActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);

        TextView mapInfo = findViewById(R.id.mapInfo);
        Button btnOpenExternalMap = findViewById(R.id.btnOpenExternalMap);

        mapInfo.setText("Map View — shows reported threats by location. Use the button to open a map app.");

        final double lat = -26.2041; // example latitude
        final double lon = 28.0473;  // example longitude

        btnOpenExternalMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri geoUri = Uri.parse("geo:" + lat + "," + lon + "?q=" + lat + "," + lon + "(SafeShare+Reports)");
                Intent mapIntent = new Intent(Intent.ACTION_VIEW, geoUri);
                mapIntent.setPackage("com.google.android.apps.maps"); // prefer Google Maps if installed
                if (mapIntent.resolveActivity(getPackageManager()) != null) {
                    startActivity(mapIntent);
                } else {
                    // fallback to any map-capable app
                    Intent fallback = new Intent(Intent.ACTION_VIEW, geoUri);
                    startActivity(fallback);
                }
            }
        });
    }
}
